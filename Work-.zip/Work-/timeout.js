const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout a user')
    .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
    .addIntegerOption(o => o.setName('minutes').setDescription('Minutes (1-1440)').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for timeout')),

  async execute(ix) {
    // Permission check
    if (!ix.member.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
      return ix.reply({ content: '❌ You don\'t have permission to timeout members!', ephemeral: true });
    }

    const user = ix.options.getUser('user');
    const minutes = ix.options.getInteger('minutes');
    const reason = ix.options.getString('reason') || 'No reason provided';
    const logChannelId = process.env.LOG_CHANNEL_ID;
    const logChannel = ix.guild.channels.cache.get(logChannelId);

    // Validate timeout duration
    if (minutes < 1 || minutes > 1440) {
      return ix.reply({ content: '❌ Timeout duration must be between 1 and 1440 minutes (24 hours)!', ephemeral: true });
    }

    try {
      // Fetch the member
      const member = await ix.guild.members.fetch(user.id).catch(() => null);
      if (!member) {
        return ix.reply({ content: '❌ User not found in this server!', ephemeral: true });
      }

      // Prevent self-timeout
      if (member.id === ix.user.id) {
        return ix.reply({ content: '❌ You cannot timeout yourself!', ephemeral: true });
      }

      // Prevent timing out the bot
      if (member.id === ix.client.user.id) {
        return ix.reply({ content: '❌ You cannot timeout me!', ephemeral: true });
      }

      // Role hierarchy check
      if (member.roles.highest.position >= ix.member.roles.highest.position) {
        return ix.reply({ content: '❌ You cannot timeout someone with equal or higher role than you!', ephemeral: true });
      }

      // Bot hierarchy check
      if (member.roles.highest.position >= ix.guild.members.me.roles.highest.position) {
        return ix.reply({ content: '❌ I cannot timeout someone with higher or equal role than me!', ephemeral: true });
      }

      // Check if member is moderatable
      if (!member.moderatable) {
        return ix.reply({ content: '❌ I cannot timeout this user! They may have higher permissions than me.', ephemeral: true });
      }

      // Check if user is already timed out
      if (member.communicationDisabledUntil && member.communicationDisabledUntil > new Date()) {
        const timeLeft = Math.ceil((member.communicationDisabledUntil.getTime() - Date.now()) / 60000);
        return ix.reply({ content: `❌ User is already timed out for ${timeLeft} more minutes!`, ephemeral: true });
      }

      // Try to DM the user before timeout
      try {
        const duration = minutes >= 60 ? `${Math.floor(minutes / 60)} hour(s) and ${minutes % 60} minute(s)` : `${minutes} minute(s)`;
        await user.send(`⏳ You have been timed out in **${ix.guild.name}** for ${duration}\n**Reason:** ${reason}\n**Moderator:** ${ix.user.tag}`);
      } catch (e) {
        // User has DMs disabled, continue with timeout
      }

      // Execute the timeout
      await member.timeout(minutes * 60 * 1000, reason);

      // Success response
      const duration = minutes >= 60 ? `${Math.floor(minutes / 60)} hour(s) and ${minutes % 60} minute(s)` : `${minutes} minute(s)`;
      const embed = new EmbedBuilder()
        .setTitle('⏳ Member Timed Out')
        .addFields(
          { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
          { name: 'Moderator', value: ix.user.tag, inline: true },
          { name: 'Duration', value: duration, inline: true },
          { name: 'Reason', value: reason, inline: false }
        )
        .setColor(0xff8c00)
        .setTimestamp();

      await ix.reply({ embeds: [embed] });

      // Log to log channel
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle('⏳ Member Timed Out')
          .addFields(
            { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
            { name: 'Moderator', value: `${ix.user.tag} (${ix.user.id})`, inline: true },
            { name: 'Channel', value: ix.channel.toString(), inline: true },
            { name: 'Duration', value: duration, inline: true },
            { name: 'Reason', value: reason, inline: false }
          )
          .setColor(0xff8c00)
          .setTimestamp();
        
        logChannel.send({ embeds: [logEmbed] });
      }

    } catch (error) {
      console.error('Timeout command error:', error);
      await ix.reply({ 
        content: '❌ Failed to timeout the user. Please check my permissions and try again.', 
        ephemeral: true 
      });
    }
  }
};
