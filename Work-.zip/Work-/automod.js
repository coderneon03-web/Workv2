const { PermissionsBitField } = require('discord.js');

function register(client) {
  const logChannelId = process.env.LOG_CHANNEL_ID;
  
  const spamMap = new Map();
  const warnings = new Map(); // For bad words
  const spamWarnings = new Map(); // For spam warnings
  const userOffenses = new Map(); // Track all user offenses for escalation

  client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.guild) return;
    
    const member = message.member;
    const logChannel = message.guild.channels.cache.get(logChannelId);
    
    if (member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return;

    const userId = message.author.id;
    const now = Date.now();
    
    if (!spamMap.has(userId)) {
      spamMap.set(userId, []);
    }
    
    const userMessages = spamMap.get(userId);
    userMessages.push(now);
    
    const recentMessages = userMessages.filter(time => now - time < 5000);
    spamMap.set(userId, recentMessages);
    
    // Enhanced spam detection with 3-warning system
    if (recentMessages.length >= 5) {
      try {
        // Delete spam messages first (bulkDelete takes a number for recent messages)
        const messagesToDelete = Math.min(recentMessages.length, 10);
        
        if (messagesToDelete > 0) {
          await message.channel.bulkDelete(messagesToDelete, true).catch(() => {});
        }
        
        const currentSpamWarnings = spamWarnings.get(userId) || 0;
        const newWarningCount = currentSpamWarnings + 1;
        spamWarnings.set(userId, newWarningCount);
        
        // Track total offenses for this user
        const totalOffenses = userOffenses.get(userId) || 0;
        const newOffenseCount = totalOffenses + 1;
        userOffenses.set(userId, newOffenseCount);
        
        if (newWarningCount >= 3) {
          // 3rd spam warning = mute for 10 minutes
          await member.timeout(600000, 'Auto-mod: Spam - 3 warnings reached');
          await message.channel.send(`🔇 ${message.author} has been muted for 10 minutes due to repeated spam violations!`);
          logChannel?.send(`🤖 **AutoMod**: Muted ${message.author.tag} for spam (3/3 warnings)`);
          spamWarnings.delete(userId);
          
          // Check for instant ban if too many total offenses
          if (newOffenseCount >= 6) {
            try {
              await member.ban({ reason: 'Auto-mod: Multiple serious violations - pattern of abuse detected' });
              logChannel?.send(`🚨 **AutoMod**: BANNED ${message.author.tag} for pattern of abuse (${newOffenseCount} total offenses)`);
              userOffenses.delete(userId);
            } catch (banError) {
              logChannel?.send(`⚠️ **AutoMod**: Failed to ban ${message.author.tag} - insufficient permissions`);
            }
          }
        } else {
          // Check for instant ban if 6th total offense reached
          if (newOffenseCount >= 6) {
            try {
              await member.ban({ reason: 'Auto-mod: Multiple serious violations - 6+ offenses reached' });
              logChannel?.send(`🚨 **AutoMod**: BANNED ${message.author.tag} for pattern of abuse (${newOffenseCount} total offenses)`);
              userOffenses.delete(userId);
              spamWarnings.delete(userId);
              return;
            } catch (banError) {
              logChannel?.send(`⚠️ **AutoMod**: Failed to ban ${message.author.tag} for 6+ offenses - insufficient permissions`);
            }
          }
          
          // First or second spam warning
          const warningEmoji = newWarningCount === 1 ? '⚠️' : '🚨';
          const warningMessage = `${warningEmoji} ${message.author}, stop spamming! Warning ${newWarningCount}/3 - Next warning = mute!`;
          
          await message.channel.send(warningMessage);
          logChannel?.send(`🤖 **AutoMod**: Warned ${message.author.tag} for spam (${newWarningCount}/3)`);
          
          // Clear spam warnings after 5 minutes if no more spam
          setTimeout(() => {
            if (spamWarnings.get(userId) === newWarningCount) {
              spamWarnings.delete(userId);
            }
          }, 300000);
        }
        
        spamMap.delete(userId);
        return;
      } catch (e) {
        console.error('Spam detection error:', e.message);
      }
    }

    const badWords = ['badword1', 'badword2', 'toxic', 'spam'];
    const content = message.content.toLowerCase();
    const hasBadWord = badWords.some(word => content.includes(word));
    
    if (hasBadWord) {
      await message.delete().catch(() => {});
      
      const userWarnings = warnings.get(userId) || 0;
      warnings.set(userId, userWarnings + 1);
      
      // Track total offenses
      const totalOffenses = userOffenses.get(userId) || 0;
      const newOffenseCount = totalOffenses + 1;
      userOffenses.set(userId, newOffenseCount);
      
      if (userWarnings + 1 >= 3) {
        await member.timeout(1800000, 'Auto-mod: Multiple bad word violations'); // 30 min timeout
        await message.channel.send(`🔇 ${message.author} has been muted for 30 minutes due to repeated inappropriate language!`);
        logChannel?.send(`🤖 **AutoMod**: Muted ${message.author.tag} for repeated bad language (3/3 warnings)`);
        warnings.delete(userId);
        
        // Check for instant ban if too many total offenses
        if (newOffenseCount >= 6) {
          try {
            await member.ban({ reason: 'Auto-mod: Multiple serious violations - pattern of abuse detected' });
            logChannel?.send(`🚨 **AutoMod**: BANNED ${message.author.tag} for pattern of abuse (${newOffenseCount} total offenses)`);
            userOffenses.delete(userId);
          } catch (banError) {
            logChannel?.send(`⚠️ **AutoMod**: Failed to ban ${message.author.tag} - insufficient permissions`);
          }
        }
      } else {
        // Check for instant ban if 6th total offense reached
        if (newOffenseCount >= 6) {
          try {
            await member.ban({ reason: 'Auto-mod: Multiple serious violations - 6+ offenses reached' });
            logChannel?.send(`🚨 **AutoMod**: BANNED ${message.author.tag} for pattern of abuse (${newOffenseCount} total offenses)`);
            userOffenses.delete(userId);
            warnings.delete(userId);
            return;
          } catch (banError) {
            logChannel?.send(`⚠️ **AutoMod**: Failed to ban ${message.author.tag} for 6+ offenses - insufficient permissions`);
          }
        }
        
        const warningEmoji = userWarnings + 1 === 1 ? '⚠️' : userWarnings + 1 === 2 ? '🚨' : '💀';
        await message.channel.send(`${warningEmoji} ${message.author}, please watch your language! Warning ${userWarnings + 1}/3`);
        logChannel?.send(`🤖 **AutoMod**: Warned ${message.author.tag} for bad language (${userWarnings + 1}/3)`);
      }
    }

    if (message.content.length >= 10) {
      const capsPercent = (message.content.match(/[A-Z]/g) || []).length / message.content.length;
      if (capsPercent >= 0.5) {
        await message.delete().catch(() => {});
        await message.channel.send(`🔇 ${message.author}, please don't use excessive caps!`);
        logChannel?.send(`🤖 **AutoMod**: Deleted caps message from ${message.author.tag}`);
      }
    }

    // Enhanced mass mentions detection with instant action for severe cases
    if (message.mentions.users.size >= 5) {
      await message.delete().catch(() => {});
      
      const totalOffenses = userOffenses.get(userId) || 0;
      const newOffenseCount = totalOffenses + 1;
      userOffenses.set(userId, newOffenseCount);
      
      if (message.mentions.users.size >= 10) {
        // Instant ban for extreme mass mentions (10+ mentions = likely bot or serious abuse)
        try {
          await member.ban({ reason: 'Auto-mod: Extreme mass mentions (10+) - likely bot or serious abuse' });
          logChannel?.send(`🚨 **AutoMod**: INSTANTLY BANNED ${message.author.tag} for extreme mass mentions (${message.mentions.users.size} mentions)`);
          userOffenses.delete(userId);
          return;
        } catch (banError) {
          logChannel?.send(`⚠️ **AutoMod**: Failed to ban ${message.author.tag} for mass mentions - insufficient permissions`);
        }
      }
      
      // Regular mass mentions (5-9) = timeout
      await member.timeout(600000, 'Auto-mod: Mass mentions detected');
      await message.channel.send(`🔇 ${message.author} has been muted for mass mentioning (${message.mentions.users.size} mentions)!`);
      logChannel?.send(`🤖 **AutoMod**: Muted ${message.author.tag} for mass mentions (${message.mentions.users.size} mentions)`);
      
      // Check for instant ban if 6th total offense
      if (newOffenseCount >= 6) {
        try {
          await member.ban({ reason: 'Auto-mod: Multiple serious violations - 6+ offenses reached' });
          logChannel?.send(`🚨 **AutoMod**: BANNED ${message.author.tag} for pattern of abuse (${newOffenseCount} total offenses)`);
          userOffenses.delete(userId);
          return;
        } catch (banError) {
          logChannel?.send(`⚠️ **AutoMod**: Failed to ban ${message.author.tag} for 6+ offenses - insufficient permissions`);
        }
      }
    }
    
    // Additional detection for potential raid/nuke attempts
    const suspiciousPatterns = [
      /discord\.gg\/[a-zA-Z0-9]+/gi, // Discord invites
      /(?:raid|nuke|destroy|fuck this server|crash|ddos)/gi, // Raid keywords
      /[@#](?:everyone|here)/gi, // @everyone/@here abuse
      /[🖕🍆🍑💦🔞]|(?:sex|porn|nude)/gi // NSFW content
    ];
    
    const hasSuspiciousContent = suspiciousPatterns.some(pattern => pattern.test(message.content));
    if (hasSuspiciousContent) {
      await message.delete().catch(() => {});
      
      const totalOffenses = userOffenses.get(userId) || 0;
      const newOffenseCount = totalOffenses + 1;
      userOffenses.set(userId, newOffenseCount);
      
      // Instant ban for raid keywords or severe violations
      if (/(?:raid|nuke|destroy|fuck this server|crash|ddos)/gi.test(message.content) || newOffenseCount >= 3) {
        try {
          await member.ban({ reason: 'Auto-mod: Suspicious activity - potential raid/abuse detected' });
          logChannel?.send(`🚨 **AutoMod**: INSTANTLY BANNED ${message.author.tag} for suspicious activity (potential raid/abuse)`);
          userOffenses.delete(userId);
          return;
        } catch (banError) {
          logChannel?.send(`⚠️ **AutoMod**: Failed to ban ${message.author.tag} - insufficient permissions`);
        }
      } else {
        // Timeout for other violations
        await member.timeout(900000, 'Auto-mod: Suspicious content detected'); // 15 minutes
        await message.channel.send(`🔇 ${message.author} has been muted for posting inappropriate content!`);
        logChannel?.send(`🤖 **AutoMod**: Muted ${message.author.tag} for suspicious content`);
      }
    }
  });
  
  // Clean up old offense records every hour to prevent memory buildup
  setInterval(() => {
    // Keep offense records for 24 hours, then gradually reduce
    for (const [userId, offenses] of userOffenses.entries()) {
      if (offenses > 0) {
        userOffenses.set(userId, Math.max(0, offenses - 1));
      } else {
        userOffenses.delete(userId);
      }
    }
  }, 3600000); // 1 hour
}

module.exports = { register };