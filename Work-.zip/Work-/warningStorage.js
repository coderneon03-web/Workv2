const fs = require('fs');
const path = require('path');

class WarningStorage {
  constructor(filePath = './warnings.json') {
    this.filePath = filePath;
    this.warnings = this.loadWarnings();
  }

  loadWarnings() {
    try {
      if (fs.existsSync(this.filePath)) {
        const data = fs.readFileSync(this.filePath, 'utf8');
        return JSON.parse(data);
      }
    } catch (error) {
      console.error('Error loading warnings:', error.message);
    }
    return {};
  }

  saveWarnings() {
    try {
      fs.writeFileSync(this.filePath, JSON.stringify(this.warnings, null, 2));
    } catch (error) {
      console.error('Error saving warnings:', error.message);
    }
  }

  addWarning(guildId, userId, moderatorId, reason, type = 'manual') {
    if (!this.warnings[guildId]) {
      this.warnings[guildId] = {};
    }
    if (!this.warnings[guildId][userId]) {
      this.warnings[guildId][userId] = [];
    }

    const warning = {
      id: Date.now(),
      moderatorId,
      reason,
      type, // 'manual', 'automod-spam', 'automod-badword', etc.
      timestamp: new Date().toISOString()
    };

    this.warnings[guildId][userId].push(warning);
    this.saveWarnings();
    return warning;
  }

  getWarnings(guildId, userId) {
    return this.warnings[guildId]?.[userId] || [];
  }

  getWarningCount(guildId, userId) {
    return this.getWarnings(guildId, userId).length;
  }

  clearWarnings(guildId, userId) {
    if (this.warnings[guildId]?.[userId]) {
      delete this.warnings[guildId][userId];
      this.saveWarnings();
      return true;
    }
    return false;
  }

  getAllUserWarnings(guildId) {
    return this.warnings[guildId] || {};
  }

  // Clean up old warnings (older than 30 days)
  cleanupOldWarnings() {
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    let cleaned = false;

    for (const guildId in this.warnings) {
      for (const userId in this.warnings[guildId]) {
        const userWarnings = this.warnings[guildId][userId];
        const filteredWarnings = userWarnings.filter(warning => 
          new Date(warning.timestamp) > thirtyDaysAgo
        );
        
        if (filteredWarnings.length !== userWarnings.length) {
          if (filteredWarnings.length === 0) {
            delete this.warnings[guildId][userId];
          } else {
            this.warnings[guildId][userId] = filteredWarnings;
          }
          cleaned = true;
        }
      }
    }

    if (cleaned) {
      this.saveWarnings();
    }
  }
}

module.exports = WarningStorage;