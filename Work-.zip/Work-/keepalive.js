import fetch from "node-fetch";

setInterval(() => {
  fetch("https://9a3545a0-d1b5-440c-9df4-6afa4288d045-00-1dqbteqgyq54l.sisko.replit.dev/")
    .then(() => console.log("Pinged server to stay awake"))
    .catch(console.error);
}, 10 * 1000); // every 10 seconds
