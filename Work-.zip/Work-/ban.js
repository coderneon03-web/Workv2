const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a user from the server')
    .addUserOption(option => option.setName('user').setDescription('User to ban').setRequired(true))
    .addStringOption(option => option.setName('reason').setDescription('Reason for ban')),

  async execute(interaction) {
    // Permission check
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
      return interaction.reply({ content: '❌ You don\'t have permission to ban members!', ephemeral: true });
    }

    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const logChannelId = process.env.LOG_CHANNEL_ID;
    const logChannel = interaction.guild.channels.cache.get(logChannelId);

    try {
      // Prevent self-ban
      if (user.id === interaction.user.id) {
        return interaction.reply({ content: '❌ You cannot ban yourself!', ephemeral: true });
      }

      // Prevent banning the bot
      if (user.id === interaction.client.user.id) {
        return interaction.reply({ content: '❌ You cannot ban me!', ephemeral: true });
      }

      // Try to fetch member (they might not be in the server)
      let member;
      try {
        member = await interaction.guild.members.fetch(user.id);
      } catch (e) {
        // User not in server, proceed with ban by ID
        member = null;
      }

      // If member exists, perform hierarchy checks
      if (member) {
        // Role hierarchy check
        if (member.roles.highest.position >= interaction.member.roles.highest.position) {
          return interaction.reply({ content: '❌ You cannot ban someone with equal or higher role than you!', ephemeral: true });
        }

        // Bot hierarchy check
        if (member.roles.highest.position >= interaction.guild.members.me.roles.highest.position) {
          return interaction.reply({ content: '❌ I cannot ban someone with higher or equal role than me!', ephemeral: true });
        }

        // Check if member is bannable
        if (!member.bannable) {
          return interaction.reply({ content: '❌ I cannot ban this user! They may have higher permissions than me.', ephemeral: true });
        }

        // Try to DM the user before banning
        try {
          await user.send(`🔨 You have been banned from **${interaction.guild.name}**\n**Reason:** ${reason}\n**Moderator:** ${interaction.user.tag}\n\nYou can appeal this ban by contacting the server moderators.`);
        } catch (e) {
          // User has DMs disabled, continue with ban
        }
      }

      // Execute the ban (works for both members and users not in server)
      await interaction.guild.members.ban(user.id, { reason: reason, deleteMessageDays: 1 });

      // Success response
      const embed = new EmbedBuilder()
        .setTitle('🔨 Member Banned')
        .addFields(
          { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
          { name: 'Moderator', value: interaction.user.tag, inline: true },
          { name: 'Status', value: member ? 'Was in server' : 'Not in server (ID ban)', inline: true },
          { name: 'Reason', value: reason, inline: false }
        )
        .setColor(0xff0000)
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });

      // Log to log channel
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle('🔨 Member Banned')
          .addFields(
            { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
            { name: 'Moderator', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
            { name: 'Channel', value: interaction.channel.toString(), inline: true },
            { name: 'Status', value: member ? 'Was in server' : 'Not in server (ID ban)', inline: true },
            { name: 'Reason', value: reason, inline: false }
          )
          .setColor(0xff0000)
          .setTimestamp();
        
        logChannel.send({ embeds: [logEmbed] });
      }

    } catch (error) {
      console.error('Ban command error:', error);
      await interaction.reply({ 
        content: '❌ Failed to ban the user. Please check my permissions and try again.', 
        ephemeral: true 
      });
    }
  },
};
