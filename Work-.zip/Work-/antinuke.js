function register(client) {
  const logChannelId = process.env.LOG_CHANNEL_ID;
  const whitelistedIds = process.env.WHITELISTED_IDS?.split(',') || [];
  
  // Track recent actions to detect mass actions
  const recentActions = new Map();
  const channelDeletions = new Map();
  const roleDeletions = new Map();
  const massKicksBans = new Map();

  client.on('guildMemberRemove', async (member) => {
    try {
      const fetchedLogs = await member.guild.fetchAuditLogs({ 
        type: 20, // MEMBER_KICK
        limit: 1 
      });
      const kickEntry = fetchedLogs.entries.first();
      
      // Also check for bans
      const banLogs = await member.guild.fetchAuditLogs({ 
        type: 22, // MEMBER_BAN_ADD
        limit: 1 
      });
      const banEntry = banLogs.entries.first();
      
      // Find the most recent action
      let entry = null;
      if (kickEntry && banEntry) {
        entry = kickEntry.createdAt > banEntry.createdAt ? kickEntry : banEntry;
      } else {
        entry = kickEntry || banEntry;
      }
      
      if (!entry) return;
      if (Date.now() - entry.createdAt > 10000) return; // Only recent actions (10 seconds)

      const executor = entry.executor;
      const logChannel = member.guild.channels.cache.get(logChannelId);
      const action = entry.action === 20 ? 'kicked' : 'banned';

      logChannel?.send(`⚠️ **AntiNuke**: ${executor.tag} ${action} ${member.user.tag}`);

      // Skip if user is whitelisted or is the bot itself
      if (whitelistedIds.includes(executor.id) || executor.bot) return;
      
      // Track recent actions by this executor
      const userId = executor.id;
      const now = Date.now();
      
      if (!recentActions.has(userId)) {
        recentActions.set(userId, []);
      }
      
      const userActions = recentActions.get(userId);
      userActions.push(now);
      
      // Clean old actions (older than 30 seconds)
      const recentUserActions = userActions.filter(time => now - time < 30000);
      recentActions.set(userId, recentUserActions);
      
      // Enhanced protection with instant ban for severe cases
      if (recentUserActions.length >= 5) {
        // Instant ban for 5+ moderation actions (likely nuke attempt)
        try {
          const exMember = await member.guild.members.fetch(executor.id);
          await exMember.ban({ reason: 'Anti-nuke: INSTANT BAN - Mass moderation actions detected (likely nuke attempt)' });
          logChannel?.send(`💀 **AntiNuke**: INSTANTLY BANNED ${executor.tag} for mass moderation actions (${recentUserActions.length} actions in 30s) - NUKE ATTEMPT DETECTED`);
          recentActions.delete(userId);
          
          // Alert all online staff
          const staffRole = member.guild.roles.cache.find(role => role.permissions.has('MODERATE_MEMBERS'));
          if (staffRole) {
            logChannel?.send(`🚨 @${staffRole.name} - URGENT: Potential server nuke attempt by ${executor.tag} has been automatically blocked and user banned!`);
          }
        } catch (err) {
          logChannel?.send(`❌ **AntiNuke**: Failed to ban ${executor.tag} for nuke attempt - insufficient permissions - MANUAL ACTION REQUIRED!`);
        }
      } else if (recentUserActions.length >= 3) {
        // Kick for 3-4 actions (escalation before ban)
        try {
          const exMember = await member.guild.members.fetch(executor.id);
          await exMember.kick('Anti-nuke: Mass moderation actions detected - final warning before ban');
          logChannel?.send(`🚨 **AntiNuke**: Kicked ${executor.tag} for mass moderation actions (${recentUserActions.length} actions in 30s) - NEXT OFFENSE = BAN`);
          recentActions.delete(userId);
        } catch (err) {
          logChannel?.send(`❌ **AntiNuke**: Failed to kick ${executor.tag} - insufficient permissions`);
        }
      }
    } catch (error) {
      console.log('AntiNuke error:', error.message);
    }
  });
  
  // Monitor channel deletions
  client.on('channelDelete', async (channel) => {
    if (!channel.guild) return;
    
    try {
      const fetchedLogs = await channel.guild.fetchAuditLogs({
        type: 12, // CHANNEL_DELETE
        limit: 1
      });
      const deleteEntry = fetchedLogs.entries.first();
      
      if (!deleteEntry || Date.now() - deleteEntry.createdAt > 10000) return;
      
      const executor = deleteEntry.executor;
      const logChannel = channel.guild.channels.cache.get(logChannelId);
      
      // Skip if whitelisted or bot
      if (whitelistedIds.includes(executor.id) || executor.bot) return;
      
      const userId = executor.id;
      const now = Date.now();
      
      if (!channelDeletions.has(userId)) {
        channelDeletions.set(userId, []);
      }
      
      const userDeletions = channelDeletions.get(userId);
      userDeletions.push(now);
      
      const recentDeletions = userDeletions.filter(time => now - time < 60000); // 1 minute
      channelDeletions.set(userId, recentDeletions);
      
      // Instant ban for 2+ channel deletions in 1 minute
      if (recentDeletions.length >= 2) {
        try {
          const exMember = await channel.guild.members.fetch(executor.id);
          await exMember.ban({ reason: 'Anti-nuke: INSTANT BAN - Multiple channel deletions detected (nuke attempt)' });
          logChannel?.send(`💀 **AntiNuke**: INSTANTLY BANNED ${executor.tag} for deleting ${recentDeletions.length} channels in 1 minute - NUKE ATTEMPT BLOCKED!`);
          channelDeletions.delete(userId);
        } catch (err) {
          logChannel?.send(`❌ **AntiNuke**: Failed to ban ${executor.tag} for channel deletions - insufficient permissions - MANUAL ACTION REQUIRED!`);
        }
      } else {
        logChannel?.send(`⚠️ **AntiNuke**: ${executor.tag} deleted channel #${channel.name} (${recentDeletions.length}/2 before auto-ban)`);
      }
    } catch (error) {
      console.log('Channel delete monitoring error:', error.message);
    }
  });
  
  // Monitor role deletions
  client.on('roleDelete', async (role) => {
    try {
      const fetchedLogs = await role.guild.fetchAuditLogs({
        type: 32, // ROLE_DELETE
        limit: 1
      });
      const deleteEntry = fetchedLogs.entries.first();
      
      if (!deleteEntry || Date.now() - deleteEntry.createdAt > 10000) return;
      
      const executor = deleteEntry.executor;
      const logChannel = role.guild.channels.cache.get(logChannelId);
      
      // Skip if whitelisted or bot
      if (whitelistedIds.includes(executor.id) || executor.bot) return;
      
      const userId = executor.id;
      const now = Date.now();
      
      if (!roleDeletions.has(userId)) {
        roleDeletions.set(userId, []);
      }
      
      const userDeletions = roleDeletions.get(userId);
      userDeletions.push(now);
      
      const recentDeletions = userDeletions.filter(time => now - time < 60000);
      roleDeletions.set(userId, recentDeletions);
      
      // Instant ban for 3+ role deletions in 1 minute
      if (recentDeletions.length >= 3) {
        try {
          const exMember = await role.guild.members.fetch(executor.id);
          await exMember.ban({ reason: 'Anti-nuke: INSTANT BAN - Multiple role deletions detected (nuke attempt)' });
          logChannel?.send(`💀 **AntiNuke**: INSTANTLY BANNED ${executor.tag} for deleting ${recentDeletions.length} roles in 1 minute - NUKE ATTEMPT BLOCKED!`);
          roleDeletions.delete(userId);
        } catch (err) {
          logChannel?.send(`❌ **AntiNuke**: Failed to ban ${executor.tag} for role deletions - insufficient permissions - MANUAL ACTION REQUIRED!`);
        }
      } else {
        logChannel?.send(`⚠️ **AntiNuke**: ${executor.tag} deleted role @${role.name} (${recentDeletions.length}/3 before auto-ban)`);
      }
    } catch (error) {
      console.log('Role delete monitoring error:', error.message);
    }
  });
  
  // Clean up tracking maps every 5 minutes
  setInterval(() => {
    const fiveMinutesAgo = Date.now() - 300000;
    
    for (const [userId, actions] of recentActions.entries()) {
      const recentActions = actions.filter(time => time > fiveMinutesAgo);
      if (recentActions.length === 0) {
        recentActions.delete(userId);
      } else {
        recentActions.set(userId, recentActions);
      }
    }
    
    for (const [userId, deletions] of channelDeletions.entries()) {
      const recentDeletions = deletions.filter(time => time > fiveMinutesAgo);
      if (recentDeletions.length === 0) {
        channelDeletions.delete(userId);
      } else {
        channelDeletions.set(userId, recentDeletions);
      }
    }
    
    for (const [userId, deletions] of roleDeletions.entries()) {
      const recentDeletions = deletions.filter(time => time > fiveMinutesAgo);
      if (recentDeletions.length === 0) {
        roleDeletions.delete(userId);
      } else {
        roleDeletions.set(userId, recentDeletions);
      }
    }
  }, 300000); // 5 minutes
}

module.exports = { register };