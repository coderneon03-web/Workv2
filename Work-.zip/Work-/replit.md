# Ally Bot - Advanced Discord Bot

## Overview

Ally Bot is a comprehensive Discord bot that provides moderation, entertainment, utility, and automation features for Discord servers. The bot includes anti-nuke protection, ticket systems, music playback, AI features, application management, and various administrative tools. It's built with Discord.js v14 and includes a web dashboard for monitoring and configuration.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Architecture
- **Main Entry Point**: `index.js` serves as the central bot file that initializes the Discord client, loads commands, registers event handlers, and sets up an Express web server
- **Command System**: Slash commands organized in feature-specific files with modular structure for easy maintenance
- **Event Handling**: Event listeners for Discord events (message creation, member joins, etc.) implemented as separate modules
- **Configuration Management**: Environment variable-based configuration through `config.js` for flexible deployment

### Security and Protection
- **Anti-Nuke System**: Monitors audit logs for suspicious activity and automatically kicks users performing mass actions (bans, kicks) unless they're whitelisted
- **Auto-Moderation**: Real-time message scanning for spam detection (5+ messages in 5 seconds), bad word filtering, and automatic timeouts
- **Permission-Based Access**: Role-based command restrictions using Discord's permission system
- **Whitelist Protection**: Configurable user whitelists for bypassing automated security measures

### Feature Modules
- **Moderation Tools**: Kick, ban, timeout, purge, warn, slowmode, and channel lock/unlock commands
- **Ticket System**: Button-based ticket creation with dedicated category organization and permission management
- **Application System**: Modal-based application forms with DM collection and channel posting
- **Music System**: Voice channel integration with queue management, playback controls, and audio streaming
- **AI Integration**: Chat assistance, image generation, code help, and translation features using external APIs

### User Engagement Systems
- **Welcome System**: Automated greeting messages for new members in designated channels
- **Auto-Role Assignment**: Automatic role assignment for new server members
- **Leveling System**: User activity tracking and ranking system
- **Logging System**: Comprehensive activity logging for moderation oversight

### Web Interface
- **Express Dashboard**: Web-based status monitoring and configuration interface
- **REST API**: Status endpoints for external monitoring and integration
- **Keep-Alive System**: Automated pinging to maintain uptime on hosted platforms

## External Dependencies

### Core Dependencies
- **Discord.js v14**: Primary Discord API wrapper for bot functionality
- **@discordjs/voice**: Voice channel integration for music features
- **@discordjs/rest**: REST API handling for Discord interactions
- **Express**: Web server framework for dashboard and API endpoints

### External Services
- **Audio Processing**: ytdl-core for YouTube audio streaming and libsodium-wrappers for voice encryption
- **Web Scraping**: Axios and Cheerio for AI feature web searches and content parsing
- **Hosting Platform**: Designed for Replit deployment with keep-alive mechanisms

### Environment Configuration
- **Discord Bot Token**: Required for bot authentication
- **Channel IDs**: Welcome, logging, applications, tickets, and secret channels
- **Role Configuration**: Auto-role assignment and permission management
- **Security Settings**: Whitelisted user IDs and authorized admin users
- **Feature Toggles**: Optional channel and category configurations for specific features