const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('apply')
    .setDescription('Start an application form'),

  async execute(interaction) {
    const modal = new ModalBuilder()
      .setCustomId('application_modal')
      .setTitle('Application Form');

    const whyApply = new TextInputBuilder()
      .setCustomId('why_apply')
      .setLabel('Why do you want to apply?')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);

    const experience = new TextInputBuilder()
      .setCustomId('experience')
      .setLabel('What experience do you have?')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);

    const availability = new TextInputBuilder()
      .setCustomId('availability')
      .setLabel('How many hours can you be active daily?')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const firstRow = new ActionRowBuilder().addComponents(whyApply);
    const secondRow = new ActionRowBuilder().addComponents(experience);
    const thirdRow = new ActionRowBuilder().addComponents(availability);

    modal.addComponents(firstRow, secondRow, thirdRow);

    await interaction.showModal(modal);
  },

  registerHandlers(client) {
    client.on('interactionCreate', async (interaction) => {
      if (!interaction.isModalSubmit() || interaction.customId !== 'application_modal') return;
      
      const whyApply = interaction.fields.getTextInputValue('why_apply');
      const experience = interaction.fields.getTextInputValue('experience');
      const availability = interaction.fields.getTextInputValue('availability');
      
      const appsChannel = interaction.guild.channels.cache.get(process.env.APPLICATIONS_CHANNEL);
      
      if (appsChannel) {
        await appsChannel.send(`📋 **New Application from ${interaction.user.tag}**\n\n**Why applying:**\n${whyApply}\n\n**Experience:**\n${experience}\n\n**Availability:**\n${availability} hours/day`);
      }
      
      await interaction.reply({ content: '✅ Your application has been submitted! Staff will review it soon.', ephemeral: true });
    });
  }
};
