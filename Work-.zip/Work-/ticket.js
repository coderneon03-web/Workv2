const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Create a support ticket'),

  async execute(interaction) {
    const ticketsCategory = process.env.TICKETS_CATEGORY;
    
    try {
      const channel = await interaction.guild.channels.create({
        name: `ticket-${interaction.user.username}`,
        type: 0, // text channel
        parent: ticketsCategory,
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ["ViewChannel"],
          },
          {
            id: interaction.user.id,
            allow: ["ViewChannel", "SendMessages"],
          },
        ],
      });

      await channel.send(`🎟️ **Ticket opened by ${interaction.user}**\nStaff will assist you soon.\n\nTo close this ticket, contact a staff member.`);
      await interaction.reply({ content: `✅ Your ticket has been created: ${channel}`, ephemeral: true });
    } catch (error) {
      await interaction.reply({ content: '❌ Failed to create ticket. Please contact an admin.', ephemeral: true });
    }
  },
};
