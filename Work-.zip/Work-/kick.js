const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a user')
    .addUserOption(o => o.setName('user').setDescription('User to kick').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason')),

  async execute(ix) {
    // Permission check
    if (!ix.member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
      return ix.reply({ content: '❌ You don\'t have permission to kick members!', ephemeral: true });
    }

    const user = ix.options.getUser('user');
    const reason = ix.options.getString('reason') || 'No reason provided';
    const logChannelId = process.env.LOG_CHANNEL_ID;
    const logChannel = ix.guild.channels.cache.get(logChannelId);

    try {
      // Fetch the member
      const member = await ix.guild.members.fetch(user.id).catch(() => null);
      if (!member) {
        return ix.reply({ content: '❌ User not found in this server!', ephemeral: true });
      }

      // Prevent self-kick
      if (member.id === ix.user.id) {
        return ix.reply({ content: '❌ You cannot kick yourself!', ephemeral: true });
      }

      // Prevent kicking the bot
      if (member.id === ix.client.user.id) {
        return ix.reply({ content: '❌ You cannot kick me!', ephemeral: true });
      }

      // Role hierarchy check
      if (member.roles.highest.position >= ix.member.roles.highest.position) {
        return ix.reply({ content: '❌ You cannot kick someone with equal or higher role than you!', ephemeral: true });
      }

      // Bot hierarchy check
      if (member.roles.highest.position >= ix.guild.members.me.roles.highest.position) {
        return ix.reply({ content: '❌ I cannot kick someone with higher or equal role than me!', ephemeral: true });
      }

      // Check if member is kickable
      if (!member.kickable) {
        return ix.reply({ content: '❌ I cannot kick this user! They may have higher permissions than me.', ephemeral: true });
      }

      // Try to DM the user before kicking
      try {
        await user.send(`👢 You have been kicked from **${ix.guild.name}**\n**Reason:** ${reason}\n**Moderator:** ${ix.user.tag}`);
      } catch (e) {
        // User has DMs disabled, continue with kick
      }

      // Execute the kick
      await member.kick(reason);

      // Success response
      const embed = new EmbedBuilder()
        .setTitle('👢 Member Kicked')
        .addFields(
          { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
          { name: 'Moderator', value: ix.user.tag, inline: true },
          { name: 'Reason', value: reason, inline: false }
        )
        .setColor(0xffa500)
        .setTimestamp();

      await ix.reply({ embeds: [embed] });

      // Log to log channel
      if (logChannel) {
        const logEmbed = new EmbedBuilder()
          .setTitle('👢 Member Kicked')
          .addFields(
            { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
            { name: 'Moderator', value: `${ix.user.tag} (${ix.user.id})`, inline: true },
            { name: 'Channel', value: ix.channel.toString(), inline: true },
            { name: 'Reason', value: reason, inline: false }
          )
          .setColor(0xffa500)
          .setTimestamp();
        
        logChannel.send({ embeds: [logEmbed] });
      }

    } catch (error) {
      console.error('Kick command error:', error);
      await ix.reply({ 
        content: '❌ Failed to kick the user. Please check my permissions and try again.', 
        ephemeral: true 
      });
    }
  }
};
